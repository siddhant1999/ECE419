function Player () {
	let url = "https://open.spotify.com/embed/track/14vexXpojwu3mG1S9fqHmL?utm_source=generator";

	return (
		<div>
<iframe 
style={{borderRadius:"12px"}}
src="https://open.spotify.com/embed/track/24RQ6qDJAQ1sa94p1qfdYh?utm_source=generator"
width="100%"
height="380"
title="player"
frameBorder="0"
></iframe>
</div>
	);
}
export default Player;